#!/system/bin/sh
OPTION=$1; FILE=$2; TAR=$3; [ ! "$TAR" ] && TAR=$FILE.xbase64; DIRFILE=`dirname $FILE`
if [ "$OPTION" == "new" ]; then
echo "#!/system/bin/sh" >$TAR
elif [ "$OPTION" == "fast" ]; then
GR="&"
fi 
echo "( mkdir -p ./$DIRFILE" >>$TAR
echo "(echo \"" >>$TAR
base64 $FILE >>$TAR
echo "\" | base64 -d" >>$TAR
echo ") >./$FILE" >>$TAR
echo " ) $GR" >>$TAR