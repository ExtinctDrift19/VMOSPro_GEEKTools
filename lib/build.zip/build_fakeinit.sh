#!/system/bin/sh
DIRNAME=`dirname $0`; cd $DIRNAME;
cp part1 init
sh b64file.sh fast tool_files/main/main.sh init
sh b64file.sh fast tool_files/main/busybox/busybox init
sh b64file.sh fast tool_files/main/busybox/busybox.vmos init
sh b64file.sh fast tool_files/main/exbin/zip init
sh b64file.sh fast tool_files/main/exbin/utils init
sh b64file.sh fast tool_files/main/exbin/aapt init
sh b64file.sh fast tool_files/main/root/subinary init
cat part2 >>init
# base64 init >init.base64
cp part3 tool.sh
sh b64file.sh add init tool.sh
cat part4 >>tool.sh