#!/system/bin/sh
DIRNAME=`dirname $0`; cd "$DIRNAME";
echo "- Build wrapper init..."
cp part1 init
LIST=" tool_files/main/main.sh
tool_files/main/busybox/busybox
tool_files/main/busybox/busybox.vmos
tool_files/main/exbin/zip
tool_files/main/exbin/utils
tool_files/main/exbin/aapt
tool_files/main/root/subinary"
for i in $LIST; do
echo "- Add $i to init"
sh b64file.sh fast $i init
done
sh b64file.sh fast "system/media/bootanimation.zip" init true
cat part2 >>init
echo "- Build fake library..."
# base64 init >init.base64
cp part3 libfake_tool.so
sh b64file.sh add init libfake_tool.so
cat part4 >>libfake_tool.so
echo "- Done!"